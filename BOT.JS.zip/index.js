const Discord = require("discord.js")
const axios = require("axios");
const config = require("./config.json")
const { QuickDB } = require("quick.db");
const db = new QuickDB()
const client = new Discord.Client({ 
  intents: [ 
Discord.GatewayIntentBits.Guilds, 959
       ]
    });

module.exports = client

client.on('interactionCreate', (interaction) => {

  if(interaction.type === Discord.InteractionType.ApplicationCommand){

      const cmd = client.slashCommands.get(interaction.commandName);

      if (!cmd) return interaction.reply(`Error`);

      interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);

      cmd.run(client, interaction)

   }
})

client.on('ready', () => {
  console.log(`🔥 Estou online em ${client.user.username}!`)
})


client.slashCommands = new Discord.Collection()

require('./handler')(client)

client.login(config.token)

client.on("ready", async() => {


setInterval(async() => {

  const servidor = client.guilds.cache.get(await db.get(`servidor`))
  if (!servidor) return;
  const icon = servidor.channels.cache.get(await  db.get(`canal-icon`))
  const gif = servidor.channels.cache.get(await db.get(`canal-gif`))
  const banner = servidor.channels.cache.get(await db.get(`canal-canalbaner`))
  
  if (!icon) return;
  if (!gif) return;
  if (!banner) return;
  const randd = servidor.members.cache.filter(a => !a.bot).random();

  if(!randd) {
    console.log(randd)
    return;
  }

  axios.get(`https://discord.com/api/users/${randd.id}`, {
    headers: {
      Authorization: "Bot " + config.token,
    }
  }).then(res => {
    if (res.data.banner) {
      if (res.data.banner.startsWith("a_")) {
        banner.send({
          embeds: [
            new Discord.EmbedBuilder().setAuthor({name: servidor.name,  iconURL: servidor.iconURL({dynamic:true, size: 1024})})
          .setColor("#9932CC")
.setFooter({text: randd.id})
            .setImage(`https://cdn.discordapp.com/banners/${randd.id}/${res.data.banner}.gif?size=2048`)
          ],
          components:[
            new Discord.ActionRowBuilder()
            .addComponents(
              new Discord.ButtonBuilder()
              .setLabel("Baixar imagem")
              .setStyle(5)
              .setURL(`https://cdn.discordapp.com/banners/${randd.id}/${res.data.banner}.gif?size=2048`)
            )
          ]
        })
      }
      else {
        banner.send({
          embeds: [new Discord.EmbedBuilder().setAuthor({name: servidor.name,  iconURL: servidor.iconURL({dynamic:true, size: 1024})})
          .setColor("#9932CC")
.setFooter({text: randd.id})
            .setImage(`https://cdn.discordapp.com/banners/${randd.id}/${res.data.banner}.png?size=2048`)],
            components:[
              new Discord.ActionRowBuilder()
              .addComponents(
                new Discord.ButtonBuilder()
                .setLabel("Baixar imagem")
                .setStyle(5)
                .setURL(`https://cdn.discordapp.com/banners/${randd.id}/${res.data.banner}.png?size=2048`)
              )
            ]
        })
      }

    }
  })
  .catch(() => {})
  
  const avatar = randd.displayAvatarURL({ dynamic: true, size: 1024 })

  if (avatar.includes("gif")) {
    gif.send({
      embeds: [new Discord.EmbedBuilder().setAuthor({name: servidor.name,  iconURL: servidor.iconURL({dynamic:true, size: 1024})})
      .setColor("#9932CC")
.setFooter({text: randd.id})
        .setImage(randd.displayAvatarURL({ dynamic: true, size: 1024 }))],
        
          components:[
            new Discord.ActionRowBuilder()
            .addComponents(
              new Discord.ButtonBuilder()
              .setLabel("Baixar imagem")
              .setStyle(5)
              .setURL(randd.displayAvatarURL({ dynamic: true, size: 1024 }))
            )
          ]
    })
  }
  else {
    icon.send({
      embeds: [new Discord.EmbedBuilder().setAuthor({name: servidor.name,  iconURL: servidor.iconURL({dynamic:true, size: 1024})})
      .setColor("#9932CC")
.setFooter({text: randd.id})
        .setImage(randd.displayAvatarURL({ dynamic: true, size: 1024 }))],
        
        components:[
          new Discord.ActionRowBuilder()
          .addComponents(
            new Discord.ButtonBuilder()
            .setLabel("Baixar imagem")
            .setStyle(5)
            .setURL(randd.displayAvatarURL({ dynamic: true, size: 1024 }))
          )
        ]
    })
  }
}, config.random_gif.segundos * 1000)

})