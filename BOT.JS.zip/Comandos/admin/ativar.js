const Discord = require("discord.js")
const config = require("../../config.json")
const { QuickDB } = require("quick.db")
const db = new QuickDB()

module.exports = {
    name: "ativar", 
    description: "Ative o sistema de random Gif/Icon no atual canal de texto.", 
    type: Discord.ApplicationCommandType.ChatInput,
  options: [
    {
        name: "canal-icon",
        description: "Canal de icones",
        type: Discord.ApplicationCommandOptionType.Channel,
        required: true,
    },
    {
        name: "canal-gifs",
        description: "Canal de gifs",
        type: Discord.ApplicationCommandOptionType.Channel,
        required: true,
    },
    {
        name: "canal-banner",
        description: "Canal de banners",
        type: Discord.ApplicationCommandOptionType.Channel,
        required: true,
    }
],

  run: async (client, interaction) => {
    if(interaction.user.id !== config.random_gif.owner_id) return interaction.reply({content:"Você não pode usar esta opção"})

    const canalicon = interaction.options.getChannel("canal-icon")
    const canalgifs = interaction.options.getChannel("canal-gifs")
    const canalbanner = interaction.options.getChannel("canal-banner")


    await db.set(`canal-icon`, canalicon.id)
    await db.set(`canal-gif`, canalgifs.id)
    await db.set(`canal-canalbaner`, canalbanner.id)
    await db.set(`servidor`, interaction.guild.id)

        interaction.reply({ content: `As configurações foram concluídas e o sistema foi ativado.`, ephemeral: true })
    
  }
}