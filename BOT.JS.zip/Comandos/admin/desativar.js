const Discord = require("discord.js")
const config = require("../../config.json")
const { QuickDB } = require("quick.db")
const db = new QuickDB()

module.exports = {
  name: "desativar", 
  description: "Desative o sistema de random Gif/Icon no servidor.", 
  type: Discord.ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {

    if (interaction.user.id !== config.random_gif.owner_id) {
        return;
    } else {
        await db.delete(`canal-icon`)
        await db.delete(`canal-gif`)
        await db.delete(`canal-canalbaner`)
        await db.delete(`servidor`)

        interaction.reply({ content: `As configurações foram concluídas e o sistema foi desativado.`, ephemeral: true })
    }
  }
}